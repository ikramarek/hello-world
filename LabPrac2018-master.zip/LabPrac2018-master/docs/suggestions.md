# Suggestions 

A bunch of ideas for studies you might try to replicate. 

&nbsp;

&nbsp;

### Impact of metaphors on reasoning

| &nbsp;     | 
| :--- | :--- 
| Authors | Paul H. Thibodeau & Lera Boroditsky
| Title | [Metaphors We Think With: The Role of Metaphor in Reasoning](http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0016782)
| Keywords | pragmatics, metaphors, reasoning
| Difficulty | easy
| Group | 2-3

&nbsp;


